
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Mahasiswa Yang Terlibat</h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <form action="/editpkm/mhs/<?php echo e($id); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group row" id="isian">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 mb-3 mb-sm-0 mt-2 ml-4 card shadows">
                    <input type="text" hidden class="form-control" id="ids[<?php echo e($key); ?>]" name="ids[<?php echo e($key); ?>]" value="<?php echo e($data[$key]->id); ?>">
                    <p><b>Nama</b>
                        <input type="text" class="form-control" id="nama[<?php echo e($key); ?>]" name="nama[<?php echo e($key); ?>]" value="<?php echo e($data[$key]->nama); ?>"
                        placeholder="Nama">
                    </p>
                    <p><b>Nrp</b>
                        <input type="text" class="form-control" id="nrp[<?php echo e($key); ?>]" name="nrp[<?php echo e($key); ?>]" value="<?php echo e($data[$key]->nidn_nrp); ?>"
                        placeholder="Nrp">
                    </p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <button class="ml-2" type="button" id="tmbh">Tambah</button>
            <button class="ml-2" type="submit">Submit</button>
        </form>
    </div>
</div>
<script language="javascript" type="text/javascript">
            var i = 0;
           document.getElementById("tmbh").onclick = function() {Tambah()};
            // var x = document.querySelector('input[name="Ada"]:checked');
            function Tambah(){
                ++i;
                document.getElementById("isian").insertAdjacentHTML('beforeend',`
                <div class="col-sm-6 mb-3 mb-sm-0 ml-2">
                    
                    <p><b>Nama</b>
                        <input type="text" class="form-control" id="namabru[`+i+`]" name="namabru[`+i+`]"
                        placeholder="Nama">
                    </p>
                    <p><b>Nrp</b>
                        <input type="text" class="form-control" id="nrpbru[`+i+`]" name="nrpbru[`+i+`]"
                        placeholder="Nrp">
                    </p>
                </div>`)
            }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('temp/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rizki\Desktop\kasir\resources\views/pkm/mahasiswa.blade.php ENDPATH**/ ?>