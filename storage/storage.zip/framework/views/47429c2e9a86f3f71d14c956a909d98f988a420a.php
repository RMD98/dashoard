
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Edit Fakultas</h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <form action="/edtfakultas/<?php echo e($data->id); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <div class="col-sm-6 mb-3 mb-sm-0 ml-2">
                    <p><b>Nama</b>
                        <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e($data->nama); ?>"
                        placeholder="Nama">
                    </p>
                </div>
            </div>
            <button class="ml-2" type="submit">Submit</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('temp/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rizki\Desktop\kasir\resources\views/fakultas/edit_fakultas.blade.php ENDPATH**/ ?>