
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Heading -->
    
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h1 class="h3 mb-2 text-gray-800" style="text-align :center"><?php echo $data->judul ?></h1>
        </div>
        <div class="card-body">
            <div class="row" style="border-bottom-width :3px; border-bottom-style: solid; border-bottom-color:black;" >
                <div class="ml-4" style="width:50%">
                    <p>Judul Pkm: <?php echo $data->judul?></p>
                    <p>Bidang :<?php echo $data->bidang?></p>
                    <p>Kesesuain Dengan Roadmap :<?php echo $data->roadmap?></p>
                    <p>Jenis Kegiatan: <?php echo $data->jeniskegiatan?></p>
                    <p>Skala : <?php echo $data->skala?></p>
                    <p>Sumber IPTEK : <?php echo $data->sumberiptek?></p>
                </div>
                <div class="ml-5">
                    <p>Tahun Kegiatan : 
                    <?php if($data->tahun_mulai==$data->tahun_akhir): ?>
                        <?php echo $data->tahun_mulai?></p>
                    <?php else: ?>
                        <?php echo $data->tahun_mulai;echo '-'; echo $data->tahun_akhir?></p>
                    <?php endif; ?>
                    <p>Dana : <?php echo $data->dana?></p>
                    <p>Sumber Dana : <?php echo $data->sumberdana?></p>
                    <p>Dana Pendamping : <?php echo $data->danapendamping?></p>
                    <p>Labolatorium : <?php echo $data->lab?></p>
                    <p>Kelengkapan : <?php echo $data->kelengkapan?></p>
                </div>
            </div>
            <div class="ml-2 mt-3">
                <h3>Anggota</h3>
            </div>
            <div class="" style="border-bottom-width :3px; border-bottom-style: solid; border-bottom-color:black;">
                <div class="ml-4 mt-3">
                    <p>Ketua (Penulis) :
                        &nbsp
                        <a href="/pkm/ketua/<?php echo $data->id ?>">EDIT &nbsp<i class="fas fa-pencil-alt fa-sm text-white-10"></i></a>
                        </p>
                    <div class="table-responsive">
                        <table class="table table-border">
                            <thead>
                                <th>Nama</th>
                                <th>NIDN</th>
                                <th>Prgram Studi</th>
                                <th>Jenjang Pendidikan</th>
                                <th>Jabatan Fungsional</th>
                                <th>Golongan</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $ketua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ketua): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($ketua->nama); ?></td>
                                        <td><?php echo e($ketua->nidn); ?></td>
                                        <td><?php echo e($ketua->prodis); ?></td>
                                        <td><?php echo e($ketua->pendidikan); ?></td>
                                        <td><?php echo e($ketua->jab_fungsional); ?></td>
                                        <td><?php echo e($ketua->golongan); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            </table>
                        </div>
                    <p>Staff Dosen :
                        &nbsp
                        <a href="/pkm/staff/<?php echo $data->id ?>">EDIT &nbsp<i class="fas fa-pencil-alt fa-sm text-white-10"></i></a>
                    </p>
                    <div class="table-responsive">
                        <table class="table table-border">
                            <thead>
                                <th>Nama</th>
                                <th>NIDN</th>
                                <th>Prgram Studi</th>
                                <th>Jenjang Pendidikan</th>
                                <th>Jabatan Fungsional</th>
                                <th>Golongan</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($staff->nama); ?></td>
                                        <td><?php echo e($staff->nidn); ?></td>
                                        <td><?php echo e($staff->prodis); ?></td>
                                        <td><?php echo e($staff->pendidikan); ?></td>
                                        <td><?php echo e($staff->jab_fungsional); ?></td>
                                        <td><?php echo e($staff->golongan); ?></td>
                                        <td><a data-toggle="modal" data-target="#modalstaff<?php echo $staff->id ?>" class="btn btn-danger">DELETE <i class="fas fa-trash"></i></a></td>
                                        <div class="modal fade" id="modalstaff<?php echo $staff->id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Are you Sure?</h5>
                                                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">Are you sure want to delete data <?php echo $staff->nama?>.</div>
                                                    <div class="modal-footer">
                                                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                                        <a class="btn btn-primary" href="/del_pkm/<?php echo e($data->id); ?>/<?php echo $staff->id ?>">YES</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            </table>
                        </div>
                    <p>Mahasiswa :
                        &nbsp
                        <a href="/pkm/mhs/<?php echo $data->id ?>">EDIT &nbsp<i class="fas fa-pencil-alt fa-sm text-white-10"></i></a>
                    </p>
                        <div class="table-responsive">
                            <table class="table table-border">
                                <thead>
                                    <th>Nama</th>
                                    <th>NRP</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $mhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($mhs->nama); ?></td>
                                            <td><?php echo e($mhs->nidn_nrp); ?></td>
                                            <td><a data-toggle="modal" data-target="#modalmhs<?php echo $mhs->id ?>" class="btn btn-danger">DELETE <i class="fas fa-trash"></i></a></td>
                                            <div class="modal fade" id="modalmhs<?php echo $mhs->id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Are you Sure?</h5>
                                                            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">×</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">Are you sure want to delete data <?php echo $mhs->nama?>.</div>
                                                        <div class="modal-footer">
                                                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                                            <a class="btn btn-primary" href="/del_pkm/<?php echo e($data->id); ?>/<?php echo $mhs->id ?>">YES</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <p>Alumni :
                        &nbsp
                        <a href="/pkm/alm/<?php echo $data->id ?>">EDIT &nbsp<i class="fas fa-pencil-alt fa-sm text-white-10"></i></a>
                    </p>
                        <div class="table-responsive">
                            <table class="table table-border">
                                <thead>
                                    <th>Nama</th>
                                    <th>Pekerjaan</th>
                                    <th>Instansi</th>
                                    <th>Alamat</th>
                                    <th>Nomor Hp</th>
                                    <th>Prgram Studi</th>
                                    <th>Tahun Lulus</th>
                                </thead>
                                <tbody>
                                   <?php $__currentLoopData = $alm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($alm->nama); ?></td>
                                        <td><?php echo e($alm->pekerjaan); ?></td>
                                        <td><?php echo e($alm->instansi); ?></td>
                                        <td><?php echo e($alm->alamat); ?></td>
                                        <td><?php echo e($alm->nohp); ?></td>
                                        <td><?php echo e($alm->prodi); ?></td>
                                        <td><?php echo e($alm->thn_lulus); ?></td>
                                        <td><a data-toggle="modal" data-target="#modalalm<?php echo $alm->id ?>" class="btn btn-danger">DELETE <i class="fas fa-trash"></i></a></td>
                                        <div class="modal fade" id="modalalm<?php echo $alm->id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Are you Sure?</h5>
                                                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">Are you sure want to delete data <?php echo $alm->nama?>.</div>
                                                    <div class="modal-footer">
                                                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                                        <a class="btn btn-primary" href="/del_pkm/<?php echo e($data->id); ?>/<?php echo $alm->id ?>">YES</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                </table>
                        </div>
                </div>
            </div>
            <div class="ml-2 mt-3">
                <h3>Mitra</h3>
                <a href="/pkm/mitra/<?php echo $data->id ?>">EDIT &nbsp<i class="fas fa-pencil-alt fa-sm text-white-10"></i></a>
            </div>
            <div class="" style="border-bottom-width :3px; border-bottom-style: solid; border-bottom-color:black;">
                <div class="table-responsive">
                    <div class="ml-4 mt-3">
                        <table class="table table-border">
                            <thead>
                                <th>Nama</th>
                                <th>Jenis</th>
                                <th>Alamat</th>
                                <th>Jarak</th>
                                <th>Manfaat</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $mitra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mitra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($mitra->nama); ?></td>
                                    <td><?php echo e($mitra->jenis); ?></td>
                                    <td><?php echo e($mitra->alamat); ?></td>
                                    <td><?php echo e($mitra->jarak); ?></td>
                                    <td><?php echo e($mitra->manfaat); ?></td>
                                    <td><a data-toggle="modal" data-target="#modalmitra<?php echo $mitra->id ?>" class="btn btn-danger">DELETE <i class="fas fa-trash"></i></a></td>
                                    <div class="modal fade" id="modalmitra<?php echo $mitra->id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Are you Sure?</h5>
                                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">Are you sure want to delete data <?php echo $mitra->nama?>.</div>
                                                <div class="modal-footer">
                                                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                                    <a class="btn btn-primary" href="/del_pkm/mitra/<?php echo e($data->id); ?>/<?php echo $mitra->id ?>">YES</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="ml-2 mt-3">
                <h3>Luaran</h3>
            </div>
            <div style="border-bottom-width :3px; border-bottom-style: solid; border-bottom-color:black;">
                <div class="ml-4 mt-3">
                    <p>Iptek Lainnya :
                        &nbsp
                        <a href="/pkm/luaran/ipteklain/<?php echo $data->id ?>">EDIT &nbsp<i class="fas fa-pencil-alt fa-sm text-white-10"></i></a>
                    </p>
                    <div class="table-responsive">
                        <table class="table table-border">
                            <thead>
                                <th>Judul</th>
                                <th>Nidn Penulis</th>
                                <th>Nama Penulis</th>
                                <th>Jenis</th>
                                <th>Deskripsi</th>
                                <th>Bukti</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $luaran['ipteklain']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($luaran['ipteklain'][$key]->judul); ?></td>
                                    <td><?php echo e($luaran['ipteklain'][$key]->nidn); ?></td>
                                    <td><?php echo e($luaran['ipteklain'][$key]->nama); ?></td>
                                    <td><?php echo e($luaran['ipteklain'][$key]->jenis); ?></td>
                                    <td><?php echo e($luaran['ipteklain'][$key]->deskripsi); ?></td>
                                    <td>
                                        <?php if($luaran['ipteklain'][$key]->bukti !=NULL): ?>
                                            <a href="/iptek_down/<?php echo e($value->id); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                                <i class="fas fa-download fa-sm text-white-50"></i>
                                            Download</a>
                                            <a href="/iptek_file/<?php echo e($value->id); ?>"  target="_blank"class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                                <i class="fas fa-eye fa-sm text-white-50"></i>
                                            Show</a>
                                        <?php else: ?>
                                           Tidak Ada File
                                        <?php endif; ?>
                                    </td>
                                    <td><a data-toggle="modal" data-target="#modaliptek<?php echo $luaran['ipteklain'][$key]->id ?>" class="btn btn-danger">DELETE <i class="fas fa-trash"></i></a></td>
                                    <div class="modal fade" id="modaliptek<?php echo $luaran['ipteklain'][$key]->id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Are you Sure?</h5>
                                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">Are you sure want to delete data <?php echo $luaran['ipteklain'][$key]->judul?>.</div>
                                                <div class="modal-footer">
                                                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                                    <a class="btn btn-primary" href="/del_pkm/iptek/<?php echo e($data->id); ?>/<?php echo $luaran['ipteklain'][$key]->id ?>">YES</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            </table>
                    </div>
                </div>
                <div class="ml-4 mt-3">
                    <p>Haki :
                        &nbsp
                        <a href="/pkm/luaran/haki/<?php echo $data->id ?>">EDIT &nbsp<i class="fas fa-pencil-alt fa-sm text-white-10"></i></a>
                    </p>
                    <div class="table-responsive">
                        <table class="table table-border">
                            <thead>
                                <th>Judul</th>
                                <th>Penulis</th>
                                <th>Jenis</th>
                                <th>No. Daftar</th>
                                <th>Status</th>
                                <th>Bukti</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $luaran['haki']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($luaran['haki'][$key]->judul); ?></td>
                                    <td>
                                        
                                        <?php $__currentLoopData = $luaran['penulishaki']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p>
                                                <?php echo e($luaran['penulishaki'][$key]->nidn); ?> - <?php echo e($luaran['penulishaki'][$key]->nama); ?>

                                            </p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e($luaran['haki'][$key]->jenis); ?></td>
                                    <td><?php echo e($luaran['haki'][$key]->no_daftar); ?></td>
                                    <td><?php echo e($luaran['haki'][$key]->status); ?></td>
                                     <td>
                                        <?php if($luaran['haki'][$key]->bukti !=NULL): ?>
                                            <a href="/haki_down/<?php echo e($value->id); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                                <i class="fas fa-download fa-sm text-white-50"></i>
                                            Download</a>
                                            <a href="/haki_file/<?php echo e($value->id); ?>" target="_blank" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                                <i class="fas fa-eye fa-sm text-white-50"></i>
                                            Show</a>
                                        <?php else: ?>
                                           Tidak Ada File
                                        <?php endif; ?>
                                    </td>
                                    <td><a data-toggle="modal" data-target="#modalhaki<?php echo $luaran['haki'][$key]->id ?>" class="btn btn-danger">DELETE <i class="fas fa-trash"></i></a></td>
                                    <div class="modal fade" id="modalhaki<?php echo $luaran['haki'][$key]->id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Are you Sure?</h5>
                                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">Are you sure want to delete data <?php echo $luaran['haki'][$key]->nama?>.</div>
                                                <div class="modal-footer">
                                                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                                    <a class="btn btn-primary" href="/del_pkm/haki/<?php echo e($data->id); ?>/<?php echo $luaran['haki'][$key]->id ?>">YES</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            </table>
                    </div>
                </div>
                <div class="ml-4 mt-3">
                    <p>Produk Tersertifikasi :
                        &nbsp
                        <a href="/pkm/luaran/prodser/<?php echo $data->id ?>">EDIT &nbsp<i class="fas fa-pencil-alt fa-sm text-white-10"></i></a>
                    </p>
                    <div class="table-responsive">
                        <table class="table table-border">
                            <thead>
                                <th>Judul</th>
                                <th>Penulis</th>
                                <th>Instansi</th>
                                <th>No. Keputusan</th>
                                <th>Bukti</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $luaran['prod_sertif']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($luaran['prod_sertif'][$key]->judul); ?></td>
                                    <td>
                                        
                                        <?php $__currentLoopData = $luaran['prod_sertif']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p>
                                                <?php echo e($luaran['prod_sertif'][$key]->nidn); ?> - <?php echo e($luaran['prod_sertif'][$key]->nama); ?>

                                            </p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e($luaran['prod_sertif'][$key]->instansi); ?></td>
                                    <td><?php echo e($luaran['prod_sertif'][$key]->no_keputusan); ?></td>
                                     <td>
                                        <?php if($luaran['prod_sertif'][$key]->bukti !=NULL): ?>
                                            <a href="/sertif_down/<?php echo e($value->id); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                                <i class="fas fa-download fa-sm text-white-50"></i>
                                            Download</a>
                                            <a href="/sertif_file/<?php echo e($value->id); ?>" target="_blank" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                                <i class="fas fa-eye fa-sm text-white-50"></i>
                                            Show</a>
                                        <?php else: ?>
                                           Tidak Ada File
                                        <?php endif; ?>
                                    </td>
                                    <td><a data-toggle="modal" data-target="#modalprodser<?php echo $luaran['prod_sertif'][$key]->id ?>" class="btn btn-danger">DELETE <i class="fas fa-trash"></i></a></td>
                                    <div class="modal fade" id="modalprodser<?php echo $luaran['prod_sertif'][$key]->id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Are you Sure?</h5>
                                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">Are you sure want to delete data <?php echo $luaran['prod_sertif'][$key]->nama?>.</div>
                                                <div class="modal-footer">
                                                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                                    <a class="btn btn-primary" href="/del_pkm/prodser/<?php echo e($data->id); ?>/<?php echo $luaran['prod_sertif'][$key]->id ?>">YES</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="ml-4 mt-3">
                    <p>Produk Terstandarisasi :
                        &nbsp
                        <a href="/pkm/luaran/prodstan/<?php echo $data->id ?>">EDIT &nbsp<i class="fas fa-pencil-alt fa-sm text-white-10"></i></a>
                    </p>
                    <div class="table-responsive">
                        <table class="table table-border">
                            <thead>
                                <th>Judul</th>
                                <th>Penulis</th>
                                <th>Instansi</th>
                                <th>No. Keputusan</th>
                                <th>Bukti</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $luaran['prod_standar']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($luaran['prod_standar'][$key]->judul); ?></td>
                                    <td>
                                        
                                        <?php $__currentLoopData = $luaran['prod_standar']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p>
                                                <?php echo e($luaran['prod_standar'][$key]->nidn); ?> - <?php echo e($luaran['prod_standar'][$key]->nama); ?>

                                            </p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e($luaran['prod_standar'][$key]->instansi); ?></td>
                                    <td><?php echo e($luaran['prod_standar'][$key]->no_keputusan); ?></td>
                                     <td>
                                        <?php if($luaran['prod_standar'][$key]->bukti !=NULL): ?>
                                            <a href="/standar_down/<?php echo e($value->id); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                                <i class="fas fa-download fa-sm text-white-50"></i>
                                            Download</a>
                                            <a href="/standar_file/<?php echo e($value->id); ?>" target="_blank" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                                <i class="fas fa-eye fa-sm text-white-50"></i>
                                            Show</a>
                                        <?php else: ?>
                                           Tidak Ada File
                                        <?php endif; ?>
                                    </td>
                                    <td><a data-toggle="modal" data-target="#modalprodstan<?php echo $luaran['prod_standar'][$key]->id ?>" class="btn btn-danger">DELETE <i class="fas fa-trash"></i></a></td>
                                    <div class="modal fade" id="modalprodstan<?php echo $luaran['prod_standar'][$key]->id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Are you Sure?</h5>
                                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">Are you sure want to delete data <?php echo $luaran['prod_standar'][$key]->nama?>.</div>
                                                <div class="modal-footer">
                                                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                                    <a class="btn btn-primary" href="/del_pkm/prodstan/<?php echo e($data->id); ?>/<?php echo $luaran['prod_standar'][$key]->id ?>">YES</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="ml-4 mt-3">
                    <p>Buku :
                        &nbsp
                        <a href="/pkm/luaran/buku/<?php echo $data->id ?>">EDIT &nbsp<i class="fas fa-pencil-alt fa-sm text-white-10"></i></a>
                    </p>
                    <div class="table-responsive">
                        <table class="table table-border">
                            <thead>
                                <th>Judul</th>
                                <th>Penulis</th>
                                <th>Jenis</th>
                                <th>Penerbit</th>
                                <th>ISBN</th>
                                <th>Jumlah Halaman</th>
                                <th>Bukti</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $luaran['buku']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($luaran['buku'][$key]->judul); ?></td>
                                    <td>
                                        
                                        <?php $__currentLoopData = $luaran['buku']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p>
                                                <?php echo e($luaran['buku'][$key]->nidn); ?> - <?php echo e($luaran['buku'][$key]->nama); ?>

                                            </p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e($luaran['buku'][$key]->jenis); ?></td>
                                    <td><?php echo e($luaran['buku'][$key]->penerbit); ?></td>
                                    <td><?php echo e($luaran['buku'][$key]->isbn); ?></td>
                                    <td><?php echo e($luaran['buku'][$key]->jum_halaman); ?></td>
                                     <td>
                                        <?php if($luaran['buku'][$key]->bukti !=NULL): ?>
                                            <a href="/buku_down/<?php echo e($value->id); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                                <i class="fas fa-download fa-sm text-white-50"></i>
                                            Download</a>
                                            <a href="/buku_file/<?php echo e($value->id); ?>" target="_blank" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                                <i class="fas fa-eye fa-sm text-white-50"></i>
                                            Show</a>
                                        <?php else: ?>
                                           Tidak Ada File
                                        <?php endif; ?>
                                    </td>
                                    <td><a data-toggle="modal" data-target="#modalbuku<?php echo $luaran['buku'][$key]->id ?>" class="btn btn-danger">DELETE <i class="fas fa-trash"></i></a></td>
                                    <div class="modal fade" id="modalbuku<?php echo $luaran['buku'][$key]->id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Are you Sure?</h5>
                                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">Are you sure want to delete data <?php echo $luaran['buku'][$key]->nama?>.</div>
                                                <div class="modal-footer">
                                                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                                    <a class="btn btn-primary" href="/del_pkm/buku/<?php echo e($data->id); ?>/<?php echo $luaran['buku'][$key]->id ?>">YES</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="ml-4 mt-3">
                    <p>Mitra Berbadan Hukum :
                        &nbsp
                        <a href="/pkm/luaran/mitrahukum/<?php echo $data->id ?>">EDIT &nbsp<i class="fas fa-pencil-alt fa-sm text-white-10"></i></a>
                    </p>
                    <div class="table-responsive">
                        <table class="table table-border">
                            <thead>
                                <th>Nama</th>
                                <th>No. Badan Hukum</th>
                                <th>Bidang Usaha</th>
                                <th>Bukti</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $luaran['mbh']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($luaran['mbh'][$key]->nama); ?></td>
                                    <td><?php echo e($luaran['mbh'][$key]->no_badan_hukum); ?></td>
                                    <td><?php echo e($luaran['mbh'][$key]->bidang_usaha); ?></td>
                                     <td>
                                        <?php if($luaran['mbh'][$key]->bukti !=NULL): ?>
                                            <a href="/mbh_down/<?php echo e($value->id); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                                <i class="fas fa-download fa-sm text-white-50"></i>
                                            Download</a>
                                            <a href="/mbh_file/<?php echo e($value->id); ?>" target="_blank" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                                <i class="fas fa-eye fa-sm text-white-50"></i>
                                            Show</a>
                                        <?php else: ?>
                                           Tidak Ada File
                                        <?php endif; ?>
                                    </td>
                                    <td><a data-toggle="modal" data-target="#modalmbh<?php echo $luaran['mbh'][$key]->id ?>" class="btn btn-danger">DELETE <i class="fas fa-trash"></i></a></td>
                                    <div class="modal fade" id="modalmbh<?php echo $luaran['mbh'][$key]->id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Are you Sure?</h5>
                                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">Are you sure want to delete data <?php echo $luaran['mbh'][$key]->nama?>.</div>
                                                <div class="modal-footer">
                                                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                                    <a class="btn btn-primary" href="/del_pkm/mitrahukum/<?php echo e($data->id); ?>/<?php echo $luaran['mbh'][$key]->id ?>">YES</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="ml-4 mt-3">
                    <p>Pemakalah di Forum Ilmiah :
                        &nbsp
                        <a href="/pkm/luaran/forum/<?php echo $data->id ?>">EDIT &nbsp<i class="fas fa-pencil-alt fa-sm text-white-10"></i></a>
                    </p>
                    <div class="table-responsive">
                        <table class="table table-border">
                            <thead>
                                <th>Judul Makalah </th>
                                <th>Penulis</th>
                                <th>Judul Forum Ilmiah</th>
                                <th>Tingkat</th>
                                <th>ISBN</th>
                                <th>Penyelenggara</th>
                                <th>Tanggal Diselenggarakan</th>
                                <th>Tempat</th>
                                <th>Bukti</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $luaran['forum_ilmiah']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($value->judul); ?></td>
                                    <td>
                                        
                                        <?php $__currentLoopData = $luaran['penulismakalah']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p>
                                            <?php echo e($values->nidn); ?> - <?php echo e($values->nama); ?>

                                        </p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e($value->judul_forum); ?></td>
                                    <td><?php echo e($value->tingkat); ?></td>
                                    <td><?php echo e($value->isbn); ?></td>
                                    <td><?php echo e($value->penyelenggara); ?></td>
                                    <td><?php echo e($value->dari); ?> - <?php echo e($value->sampai); ?></td>
                                    <td><?php echo e($value->tempat); ?></td>
                                     <td>
                                        <?php if($value->bukti !=NULL): ?>
                                            <a href="/forum_down/<?php echo e($value->id); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                                <i class="fas fa-download fa-sm text-white-50"></i>
                                            Download</a>
                                            <a href="/forum_file/<?php echo e($value->id); ?>" target="_blank" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                                <i class="fas fa-eye fa-sm text-white-50"></i>
                                            Show</a>
                                        <?php else: ?>
                                           Tidak Ada File
                                        <?php endif; ?>
                                    </td>
                                    <td><a data-toggle="modal" data-target="#modalforum<?php echo e($value->id); ?>" class="btn btn-danger">DELETE <i class="fas fa-trash"></i></a></td>
                                    <div class="modal fade" id="modalforum<?php echo e($value->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Are you Sure?</h5>
                                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">Are you sure want to delete data <?php echo $value->nama?>.</div>
                                                <div class="modal-footer">
                                                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                                    <a class="btn btn-primary" href="/del_pkm/forum/<?php echo e($data->id); ?>/<?php echo e($value->id); ?>">YES</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="ml-4 mt-3">
                    <p>Media Massa :
                        &nbsp
                        <a href="/pkm/luaran/media/<?php echo $data->id ?>">EDIT &nbsp<i class="fas fa-pencil-alt fa-sm text-white-10"></i></a>
                    </p>
                    <div class="table-responsive">
                        <table class="table table-border">
                            <thead>
                                <th>Judul</th>
                                <th>URL</th>
                                <th>Penulis</th>
                                <th>Nama Media</th>
                                <th>Jenis</th>
                                <th>Volume</th>
                                <th>Nomor</th>
                                <th>Halaman</th>
                                <th>Tanggal Terbit</th>
                                <th>Skala</th>
                                <th>Bukti</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $luaran['media_massa']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($luaran['media_massa'][$key]->judul); ?></td>
                                    <td><?php echo e($luaran['media_massa'][$key]->url); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $luaran['media_massa']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p>
                                                <?php echo e($luaran['media_massa'][$key]->nidn); ?> - <?php echo e($luaran['media_massa'][$key]->nama); ?>

                                            </p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e($luaran['media_massa'][$key]->nama_media); ?></td>
                                    <td><?php echo e($luaran['media_massa'][$key]->jenis); ?></td>
                                    <td><?php echo e($luaran['media_massa'][$key]->volume); ?></td>
                                    <td><?php echo e($luaran['media_massa'][$key]->nomor); ?></td>
                                    <td><?php echo e($luaran['media_massa'][$key]->hal); ?></td>
                                    <td><?php echo e($luaran['media_massa'][$key]->tgl_terbit); ?></td>
                                    <td><?php echo e($luaran['media_massa'][$key]->skala); ?></td>
                                    <td>
                                        <?php if($luaran['media_massa'][$key]->bukti !=NULL): ?>
                                            <a href="/media_down/<?php echo e($value->id); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                                <i class="fas fa-download fa-sm text-white-50"></i>
                                            Download</a>
                                            <a href="/media_file/" class="d-none  target="_blank"d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                                <i class="fas fa-eye fa-sm text-white-50"></i>
                                            Show</a>
                                        <?php else: ?>
                                           Tidak Ada File
                                        <?php endif; ?>
                                    </td>
                                    <td><a data-toggle="modal" data-target="#modalalm<?php echo $luaran['media_massa'][$key]->id ?>" class="btn btn-danger">DELETE <i class="fas fa-trash"></i></a></td>
                                    <div class="modal fade" id="modalalm<?php echo $luaran['media_massa'][$key]->id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Are you Sure?</h5>
                                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">Are you sure want to delete data <?php echo $luaran['media_massa'][$key]->nama?>.</div>
                                                <div class="modal-footer">
                                                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                                    <a class="btn btn-primary" href="/del_pkm/media/<?php echo e($data->id); ?>/<?php echo $luaran['media_massa'][$key]->id ?>">YES</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="ml-4 mt-3">
                    <p>Wirausaha Baru Mandiri :
                        &nbsp
                        <a href="/pkm/luaran/wbm/<?php echo $data->id ?>">EDIT &nbsp<i class="fas fa-pencil-alt fa-sm text-white-10"></i></a>
                    </p>
                    <div class="table-responsive">
                        <table class="table table-border">
                            <thead>
                                <th>Nama Wirausahawan</th>
                                <th>Jenis Usaha</th>
                                <th>Bukti</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $luaran['wbm']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($luaran['wbm'][$key]->nama); ?></td>
                                    <td><?php echo e($luaran['wbm'][$key]->jenis); ?></td>
                                    <td>
                                        <?php if($luaran['wbm'][$key]->bukti !=NULL): ?>
                                            <a href="/wbm_down/<?php echo e($value->id); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                                <i class="fas fa-download fa-sm text-white-50"></i>
                                            Download</a>
                                            <a href="/wbm_file/<?php echo e($value->id); ?>" cl target="_blank"ass="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                                <i class="fas fa-eye fa-sm text-white-50"></i>
                                            Show</a>
                                        <?php else: ?>
                                           Tidak Ada File
                                        <?php endif; ?>
                                        </td>
                                    <td><a data-toggle="modal" data-target="#modalwbm<?php echo $luaran['wbm'][$key]->id ?>" class="btn btn-danger">DELETE <i class="fas fa-trash"></i></a></td>
                                    <div class="modal fade" id="modalwbm<?php echo $luaran['wbm'][$key]->id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Are you Sure?</h5>
                                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">Are you sure want to delete data <?php echo $luaran['wbm'][$key]->nama?>.</div>
                                                <div class="modal-footer">
                                                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                                    <a class="btn btn-primary" href="/del_pkm/wbm/<?php echo e($data->id); ?>/<?php echo $luaran['wbm'][$key]->id ?>">YES</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="ml-4 mt-3">
                    <p><b>Jurnal Intrernasional :</b> 
                        &nbsp
                        <a href="/pkm/luaran/jurnal/<?php echo $data->id ?>">EDIT &nbsp<i class="fas fa-pencil-alt fa-sm text-white-10"></i></a>
                    </p>
                    <div class="table-responsive">
                        <table class="table table-border">
                            <thead>
                                <th>Judul</th>
                                <th>Penulis</th>
                                <th>Nama Jurnal</th>
                                <th>Jenis</th>
                                <th>URL</th>
                                <th>P-ISSN</th>
                                <th>E-ISSN</th>
                                <th>Volume</th>
                                <th>Nomor</th>
                                <th>Halaman</th>
                                <th>Bukti</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $luaran['jurnal_internasional']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($luaran['jurnal_internasional'][$key]->judul); ?></td>
                                    <td>
                                        
                                        <?php $__currentLoopData = $luaran['penulisjurnal']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p>
                                                <?php echo e($luaran['penulisjurnal'][$key]->nidn); ?> - <?php echo e($luaran['penulisjurnal'][$key]->nama); ?>

                                            </p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e($luaran['jurnal_internasional'][$key]->nama_jurnal); ?></td>
                                    <td><?php echo e($luaran['jurnal_internasional'][$key]->jenis); ?></td>
                                    <td><?php echo e($luaran['jurnal_internasional'][$key]->url); ?></td>
                                    <td><?php echo e($luaran['jurnal_internasional'][$key]->p_issn); ?></td>
                                    <td><?php echo e($luaran['jurnal_internasional'][$key]->e_issn); ?></td>
                                    <td><?php echo e($luaran['jurnal_internasional'][$key]->volume); ?></td>
                                    <td><?php echo e($luaran['jurnal_internasional'][$key]->nomor); ?></td>
                                    <td><?php echo e($luaran['jurnal_internasional'][$key]->halaman); ?></td>
                                        <td>
                                    <?php if($luaran['jurnal_internasional'][$key]->bukti !=NULL): ?>
                                        <a href="/jurnal_down/<?php echo e($value->id); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                            <i class="fas fa-download fa-sm text-white-50"></i>
                                        Download</a>
                                        <a href="/jurnal_file/<?php echo e($value->id); ?>" target="_blank" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                            <i class="fas fa-eye fa-sm text-white-50"></i>
                                        Show</a>
                                    <?php else: ?>
                                        Tidak Ada File
                                    <?php endif; ?>
                                </td>
                                    <td><a data-toggle="modal" data-target="#modaljurnal<?php echo $luaran['jurnal_internasional'][$key]->id ?>" class="btn btn-danger">DELETE <i class="fas fa-trash"></i></a></td>
                                    <div class="modal fade" id="modaljurnal<?php echo $luaran['jurnal_internasional'][$key]->id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Are you Sure?</h5>
                                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">Are you sure want to delete data <?php echo $luaran['jurnal_internasional'][$key]->nama?>.</div>
                                                <div class="modal-footer">
                                                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                                    <a class="btn btn-primary" href="/del_pkm/jurnal/<?php echo e($data->id); ?>/<?php echo $luaran['jurnal_internasional'][$key]->id ?>">YES</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
                
                    </div>  
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('temp/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rizki\Desktop\kasir\resources\views/pkm/pkm_show.blade.php ENDPATH**/ ?>