
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Edit Kegiatan PKM</h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <form action="/editpkm/<?php echo $data->id ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <div class="col-sm-6 mb-3 mb-sm-0 ml-2">
                    <p><b>Judul</b>
                        <input type="text" class="form-control" id="judul" name="judul" value="<?php echo $data->judul ?>"
                        placeholder="Judul">
                    </p>
                </div>
                <div class="col-sm-6 mb-3 mb-sm-0 ml-2">
                    <p><b>Sesuai Dengan Roadmap?</b>
                        &nbsp
                        <label for="roadmap">
                            <input type="radio" id="roadmap" name="roadmap" value="Ya" <?php echo e($data->roadmap == 'Ya' ? 'checked':''); ?>> Ya
                            <input type="radio" id="roadmap1" name="roadmap" value="Tidak" <?php echo e($data->roadmap == 'Tidak' ? 'checked':''); ?>> Tidak
                        </label>
                    </p>
                </div>
                <div class="col-sm-6 mb-3 mb-sm-0 ml-2">
                    <p><b>Bidang</b>
                        <input type="text" class="form-control" id="bidang" name="bidang" value="<?php echo $data->bidang?>"
                        placeholder="Bidang">
                    </p>
                </div>
                <div class="col-sm-6 mb-3 mb-sm-0 ml-2">
                    <p><b>Jenis Kegiatan</b>
                        &nbsp
                        <select name="jenis" id="jenis">
                            <option value="Insidental" <?php echo e($data->jeniskegiatan =='Insidental' ? 'selected' :''); ?>>Insidental < 1 bln</option>
                            <option value="Non-Insidental" <?php echo e($data->jeniskegiatan =='Non-Insidental' ? 'selected' :''); ?>>Non-Insidental 1 - 6 bln</option>
                        </select>
                    </p>
                </div>
                <div class="col-sm-6 mb-3 mb-sm-0 ml-2">
                    <p><b>Tingkat Penyelenggaraan Kegiatan</b>
                        &nbsp
                        <select name="skala" id="skala">
                            <option value="Local" <?php echo e($data->skala =='Local' ? 'selected' :''); ?>>Local</option>
                            <option value="Nasional" <?php echo e($data->skala =='Nasional' ? 'selected' :''); ?>>Nasional</option>
                        </select>
                    </p>
                </div>
                <div class="col-sm-6 mb-3 mb-sm-0 ml-2">
                    <p><b>Jumlah Dana</b>
                    <input type="number" class="form-control" id="dana" name="dana" value="<?php echo $data->dana ?>"
                    placeholder="Jumlah Dana">
                </p>
                </div>
                <div class="col-sm-6 mb-3 mb-sm-0 ml-2">
                    <p><b>Sumber Dana</b>
                    &nbsp
                    <select name="sumber" id="sumber">
                        <option value="Mandiri"<?php echo e($data->sumberdana =='Mandiri' ? 'selected' :''); ?>>Mandiri</option>
                        <option value="Internal PT"<?php echo e($data->sumberdana =='Internal PT' ? 'selected' :''); ?>>Internal PT</option>
                        <option value="Dikti" <?php echo e($data->sumberdana =='Dikti' ? 'selected' :''); ?>>Dikti</option>
                        <option value="Lembaga Nasional Selain Dikti"<?php echo e($data->sumberdana =='Lembaga Nasional Selain Dikti' ? 'selected' :''); ?>>Lembaga Nasional Selain Dikti</option>
                        <option value="Lembaga Luar Negri"<?php echo e($data->sumberdana =='Lembaga Luar Negri' ? 'selected' :''); ?>>Lembaga Luar Negri</option>
                    </select>
                </p>
                </div>
                <div class="col-sm-6 mb-3 mb-sm-0 ml-2">
                    <p><b>Tahun Kegiatan</b>
                        <input type="number" class="form-control" id="t-awal" name="tawal" placeholder="Tahun Awal" value="<?php echo $data->tahun_mulai?>">
                        &nbsp
                        <input type="number" class="form-control" id="t-akhir" name="takhir" placeholder="Tahun Akhir" value="<?php echo $data->tahun_akhir?>">
                    </p>
                </div>
                <div class="col-sm-6 mb-3 mb-sm-0 ml-2">
                    <p><b>Sumber Daya IPTEK Yang Digunakan</b>
                        <select name="sumberiptek" id="sumberiptek">
                            <?php $__currentLoopData = $iptek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iptek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo $iptek->sumber?>"><?php echo $iptek->sumber?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </p>
                </div>
                <div class="col-sm-6 mb-3 mb-sm-0 ml-2">
                    <p><b>Dana Pendamping</b>
                        <input type="number" class="form-control" id="dpend" name="dpend" placeholder="Dana Pendamping" value="<?php echo $data->danapendamping ?>">
                    </p>
                </div>
                <div class="col-sm-6 mb-3 mb-sm-0 ml-2">
                    <p><b>Laboratorium</b>
                        <input type="text" class="form-control" id="lab" name="lab" placeholder="Laboratorium" value="<?php echo $data->lab ?>">
                    </p>
                </div>
                <div class="col-sm-6 mb-3 mb-sm-0 ml-2">
                    <p><b>Kelengkapan</b>
                        &nbsp
                        <label for="kelengkapan">
                            <input type="radio" id="kelengkapan" name="kelengkapan" value="Ya"<?php echo e($data->kelengkapan =='Ya' ? 'checked' :''); ?>> Ya
                            <input type="radio" id="kelengkapan" name="kelengkapan" value="Tidak"<?php echo e($data->kelengkapan =='Tidak' ? 'checked' :''); ?>> Tidak
                        </label>
                    </p>
                </div>
            </div>
            <button class="ml-2" type="submit">Submit</button>
        </form>
    </div>
</div>
<script language="javascript" type="text/javascript">
            document.getElementById("Ada").onchange = function() {file()};
            // var x = document.querySelector('input[name="Ada"]:checked');
            function file(){
                var x = document.getElementById("roadmap");
                var y = document.getElementById("roadmap1");
                if($data->roadmap == 'Ya'){
                    x.on = true
                }
                else{
                    y.on = true
                }
            }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('temp/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rizki\Desktop\kasir\resources\views/pkm/edit_pkm.blade.php ENDPATH**/ ?>