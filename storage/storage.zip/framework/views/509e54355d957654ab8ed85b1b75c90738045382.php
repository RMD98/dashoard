
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Luaran Pemakalah di Forum Ilmiah</h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <form action="/editpkm/luaran/forum/<?php echo e($id); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group row" id="isian">
                <div class="col-sm-6 mb-3 mb-sm-0 ml-2 mt-2 card shadows">
                    <input type="text" hidden class="form-control" id="ids" name="ids" value="<?php echo e(count($data) == 0 ? '' : $data[0]->id); ?>">
                    <p><b>Judul Makalah</b>
                        <input type="text" class="form-control" id="judul" name="judul" value="<?php echo e(count($data) == 0 ? '' : $data[0]->judul); ?>"
                        placeholder="Judul Makalah">
                    </p>
                    <p><b>Nama Penulis</b>
                        <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e(count($data) == 0 ? '' : $data[0]->nama); ?>"
                        placeholder="Nama Penulis">
                    </p>
                    <p><b>NIDN Penulis</b>
                        <input type="text" class="form-control" id="nidn" name="nidn" value="<?php echo e(count($data) == 0 ? '' : $data[0]->nidn); ?>"
                        placeholder="NIDN Penulis">
                    </p>
                    <p><b>Judul Forum Ilmiah</b>
                        <input type="text" class="form-control" id="judul_forum" name="judul_forum" value="<?php echo e(count($data) == 0 ? '' : $data[0]->judul); ?>"
                        placeholder="Judul Forum Ilmiah">
                    </p>
                    <p><b>Tingkat Forum Ilmiah</b>
                        <?php if(count($data) == 0 ): ?>
                           <?php echo e($jenis = ''); ?>

                        <?php else: ?>
                           <?php echo e($jenis = $data[0]->jenis); ?>

                        <?php endif; ?>
                        <select name="tingkat" id="tingkat">
                            <option value="Lokal" <?php echo e($jenis == 'Lokal' ? 'selected' :''); ?>>
                                Lokal
                            </option>
                            <option value="Nasional" <?php echo e($jenis == 'Nasional' ? 'selected' :''); ?>>
                                Nasional
                            </option>
                            <option value="Internasional" <?php echo e($jenis == 'Internasional' ? 'selected' :''); ?>>
                                Internasional
                            </option>
                        </select>
                    </p>
                    <p><b>Penyelenggara</b>
                        <input type="text" class="form-control" id="penyelenggara" name="penyelenggara" value="<?php echo e(count($data) == 0 ? '': $data[0]->penyelenggara); ?>"
                        placeholder="Penyelenggara">
                    <p><b>ISBN</b>
                        <input type="text" class="form-control" id="isbn" name="isbn" value="<?php echo e(count($data) == 0 ? '': $data[0]->isbn); ?>"
                        placeholder="ISBN">
                    </p>
                    <p><b>Tanggal Diselenggarakan</b>
                        <input type="date" class="form-control" id="dari" name="dari" value="<?php echo e(count($data) == 0 ? '': $data[0]->dari); ?>"
                        placeholder="Dari">
                        Sampai
                        <input type="date" class="form-control" id="sampai" name="sampai" value="<?php echo e(count($data) == 0 ? '': $data[0]->sampai); ?>"
                        placeholder="sampai">
                    </p>
                    <p><b>Tempat</b>
                        <input type="text" class="form-control" id="tempat" name="tempat" value="<?php echo e(count($data) == 0 ? '': $data[0]->tempat); ?>"
                        placeholder="Tempat">
                    </p>
                    <p><b>Bukti</b>
                        <?php if(count($data) != 0): ?>
                            <?php if($data[0]->bukti !=NULL): ?>
                                <a href="/fas_down/" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                    <i class="fas fa-download fa-sm text-white-50"></i>
                                Download</a>
                                <a href="/fas_file/" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                    <i class="fas fa-eye fa-sm text-white-50"></i>
                                Show</a>
                                <input type="file" name="" id="">
                            <?php else: ?>
                                <input type="file" class="form-control" id="bukti" name="bukti" 
                                placeholder="Deskripsi">
                            <?php endif; ?>
                        <?php else: ?>
                            <input type="file" class="form-control" id="bukti" name="bukti">
                        <?php endif; ?>
                    </p>
                </div>
            </div>
            <button class="ml-2" type="submit">Submit</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('temp/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rizki\Desktop\kasir\resources\views/pkm/luaran/forum.blade.php ENDPATH**/ ?>