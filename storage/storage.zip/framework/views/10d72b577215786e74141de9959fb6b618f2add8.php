
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Luaran Haki</h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <form action="/editpkm/luaran/haki/<?php echo e($id); ?>" method="post" enctype="multipart/form-data">
            <?php if(count($data) == 0 ): ?>
                <?php echo e($jenis = ''); ?>

                <?php echo e($status = ''); ?>

            <?php else: ?>
                <?php echo e($status = $data->status); ?>

                <?php echo e($jenis = $data->jenis); ?>

            <?php endif; ?>
            <?php echo csrf_field(); ?>
            <div class="form-group row" id="isian">
                <div class="col-sm-6 mb-3 mb-sm-0 ml-2 mt-2 card shadows">
                    <input type="text" hidden class="form-control" id="ids" name="ids" value="<?php echo e(count($data) == 0 ? '' : $data[0]->id_haki); ?>">
                    <p><b>Judul</b>
                        <input type="text" class="form-control" id="judul" name="judul" value="<?php echo e(count($data) == 0 ? '' : $data[0]->judul); ?>"
                        placeholder="Judul">
                    </p>
                    <p><b>Nama Penulis</b>
                        <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e(count($data) == 0 ? '' : $data[0]->nama); ?>"
                        placeholder="Nama Penulis">
                    </p>
                    <p><b>NIDN Penulis</b>
                        <input type="text" class="form-control" id="nidn" name="nidn" value="<?php echo e(count($data) == 0 ? '' : $data[0]->nidn); ?>"
                        placeholder="NIDN Penulis">
                    </p>
                    <p><b>Jenis Luaran Iptek Lain</b>
                        <select name="jenis" id="jenis">
                            <option value="Desain Industri" <?php echo e($jenis == 'Desain Industri' ? 'selected' :''); ?>>
                                Desain Industri
                            </option>
                            <option value="Paten" <?php echo e($jenis == 'Paten' ? 'selected' :''); ?>>
                                Paten
                            </option>
                            <option value="Hak Cipta" <?php echo e($jenis == 'Hak Cipta' ? 'selected' :''); ?>>
                                Hak Cipta
                            </option>
                            <option value="Merek" <?php echo e($jenis == 'Merek' ? 'selected' :''); ?>>
                                Merek
                            </option>
                        </select>
                    </p>
                    <p><b>Nomor Pendaftaran</b>
                        <input type="text" class="form-control" 
                        id="nodaftar" name="nodaftar" value="<?php echo e(count($data) == 0 ? '': $data[0]->no_daftar); ?>"
                        placeholder="Nomor Pendaftaran">
                    </p>
                    <p><b>Bukti</b>
                        <?php if(count($data) != 0): ?>
                            <?php if($data->bukti !=NULL): ?>
                                <a href="/fas_down/" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                    <i class="fas fa-download fa-sm text-white-50"></i>
                                Download</a>
                                <a href="/fas_file/" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                    <i class="fas fa-eye fa-sm text-white-50"></i>
                                Show</a>
                                <input type="file" name="" id="">
                            <?php else: ?>
                                <input type="file" class="form-control" id="bukti" name="bukti" 
                                placeholder="Deskripsi">
                            <?php endif; ?>
                        <?php else: ?>
                            <input type="file" class="form-control" id="bukti" name="bukti">
                        <?php endif; ?>
                    </p>
                    <p>
                       <input type="checkbox" id="status" name="status" value="Terdaftar" <?php echo e($status =='Terdaftar' ? 'checked' : ''); ?>>
                       <label for="status">Terdaftar</label>
                    </p>
                </div>
            </div>
            <button class="ml-2" type="submit">Submit</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('temp/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rizki\Desktop\kasir\resources\views/pkm/luaran/haki.blade.php ENDPATH**/ ?>