
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Manajemen Pengabdian</h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="/add_manajemen" class="btn btn-primary">
                Tambah Data &nbsp
                <i class="fas fa-plus"></i>
            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                        <th>SOP</th>
                        <th>Kegiatan Pelatihan Dan Atau Klinik Proposal</th>
                        <th>Rekrutmen Reviewer Internal</th>
                        <th>Evaluasi Proposal</th>
                        <th>Seminar Pembahasan Proposal</th>
                        <th>Penetapan Pemenang</th>
                        <th>Kontrak Pelaksanaan PKM</th>
                        <th>Monitoring Dan Evaluasi Internal</th>
                        <th>Sistem Penghargaan (Reward Dan Punishment)</th>
                        <th>Pelaporan Hasil PKM</th>
                        <th>Kegiatan Seminar/Pameran Hasil PKM</th>
                        <th>Proses Penjaminan Mutu</th>
                        <th>Tindak Lanjut Hasil PKM</th>
                        <th></th>
                        </tr>
                    </thead>
                    <tbody>
                       
                        <?php $__currentLoopData = $tahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($value->tahun); ?></td>
                                <?php $__currentLoopData = $data[$value->tahun]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td>
                                        <?php echo e($value->konsistensi); ?>

                                        <br>
                                        <br>
                                        <?php if($value->file == NULL): ?>
                                            <b>
                                                <i>
                                                    Tidak Ada file
                                                </i>
                                            </b>
                                        <?php else: ?>
                                        <a href="/man_down/<?php echo e($value->id); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                            <i class="fas fa-download fa-sm text-white-50"></i>
                                            Download
                                        </a>
                                        <a href="/man_show/<?php echo e($value->id); ?>" target="_blank" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                            <i class="fas fa-eye fa-sm text-white-50"></i>
                                            Show
                                        </a>
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td>
                                    <a href="/edit_manajemen/<?php echo e($value->tahun); ?>" class="btn btn-primary">EDIT &nbsp<i class="fas fa-pencil-alt fa-sm text-white-10"></i></a>
                                    <a data-toggle="modal" data-target="#deletemodal<?php echo e($value->tahun); ?>" class="btn btn-danger">DELETE <i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        <div class="modal fade" id="deletemodal<?php echo e($value->tahun); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Are you Sure?</h5>
                                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">Are you sure want to delete data <?php echo e($value->tahun); ?>.</div>
                                    <div class="modal-footer">
                                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                        <a class="btn btn-primary" href="/del_manajemen/<?php echo e($value->tahun); ?>">YES</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('temp/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rizki\Desktop\kasir\resources\views/manajemen/manajemen.blade.php ENDPATH**/ ?>