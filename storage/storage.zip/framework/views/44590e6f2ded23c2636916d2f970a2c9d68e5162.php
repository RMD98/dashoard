
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Anggota Dosen Yang Terlibat</h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <form action="/editpkm/staff/<?php echo e($id); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group row" id="isian">
                <input type="text" hidden class="form-control" id="id" name="id" value="<?php echo e($id); ?>">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 mb-3 mb-sm-0 mt-2 ml-4 card shadows">
                    <input type="text" hidden class="form-control" id="ids[<?php echo e($key); ?>]" name="ids[<?php echo e($key); ?>]" value="<?php echo e($value->id); ?>">
                    <p><b>Nama</b>
                        <input type="text" class="form-control" id="nama[<?php echo e($key); ?>]" name="nama[<?php echo e($key); ?>]" value=""
                        placeholder="Nama">
                    </p>
                    <p><b>NIDN</b>
                        <select class="nidn form-control" onchange="Update(<?php echo e($key); ?>)" id="nidn[<?php echo e($key); ?>]" name="nidn[<?php echo e($key); ?>]" value="<?php echo e($value->nidn_nrp); ?>"
                        placeholder="NIDN"></select>
                    </p>
                    <p><b>Program Studi</b>
                    <select class="form-control" name="prodi[<?php echo e($key); ?>]" id="prodi">
                            <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys=>$prodis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($prodis->id); ?>"><?php echo e($prodis->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </p>
                    <p><b>Jenjang Pendidikan</b>
                        <input type="text" class="form-control" id="pend[<?php echo e($key); ?>]" name="pend[<?php echo e($key); ?>]" value=""
                        placeholder="Jenjang Pendidikan">
                    </p>
                    <p><b>Jabatan Fungsional</b>
                        <input type="text" class="form-control" id="jab[<?php echo e($key); ?>]" name="jab[<?php echo e($key); ?>]" value=""
                        placeholder="Jabatan Fungsional">
                    </p>
                    <p><b>Golongan</b>
                        <input type="text" class="form-control" id="gol[<?php echo e($key); ?>]" name="gol[<?php echo e($key); ?>]" value=""
                        placeholder="Golongan">
                    </p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <button class="ml-2" type="button" id="tmbh">Tambah</button>
            <button class="ml-2" type="submit">Submit</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script language="javascript" type="text/javascript">
            var i = 0;
           document.getElementById("tmbh").onclick = function() {Tambah()};
            // var x = document.querySelector('input[name="Ada"]:checked');
            function Tambah(){
                ++i;
                document.getElementById("isian").insertAdjacentHTML('beforeend',`
                <div class="col-sm-6 mb-3 mb-sm-0 mt-2 ml-4 card shadows">
                    <p><b>Nama</b>
                        <input type="text" class="form-control" id="namabru[`+i+`]" name="namabru[`+i+`]"
                        placeholder="Nama">
                    </p>
                    <p><b>NIDN</b>
                        <select class="nidnbru form-control" onchange="UpdateBru(${i})" id="nidnbru${i}" name="nidnbru[${i}]"></select>
                    </p>
                    <p><b>Program Studi</b>
                        <select class="form-control" name="prodibru[`+i+`]" id="prodibru[`+i+`]">
                            <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($prodi->id); ?>"><?php echo e($prodi->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </p>
                    <p><b>Jenjang Pendidikan</b>
                        <input type="text" class="form-control" id="pendbru[`+i+`]" name="pendbru[`+i+`]"
                        placeholder="Jenjang Pendidikan">
                    </p>
                    <p><b>Jabatan Fungsional</b>
                        <input type="text" class="form-control" id="jabbru[`+i+`]" name="jabbru[`+i+`]"
                        placeholder="Jabatan Fungsional">
                    </p>
                    <p><b>Golongan</b>
                        <input type="text" class="form-control" id="golbru[`+i+`]" name="golbru[`+i+`]"
                        placeholder="Golongan">
                    </p>
                </div>`)
                Select()
            };
            function UpdateBru(key){
                var dt = $(`#nidnbru${key}`).select2('val');
                console.log(dt)
                $.get('/dosens',{q:dt},function (dosen, textStatus,jqXHR){
                        console.log(dosen);  
                        document.getElementById(`namabru[${key}]`).value = dosen.nama;
                        document.getElementById(`pendbru[${key}]`).value = dosen.pendidikan;
                        document.getElementById(`jabbru[${key}]`).value = dosen.jab_fungsional;
                        document.getElementById(`golbru[${key}]`).value = dosen.golongan;
                        $(`select[name='prodibru[${key}]'] option[value='${dosen.prodi}']`).prop('selected',true);
                        //Belum NIDN
                    })
            }
            function Select(){
                $(`.nidnbru`).select2(
                    {
                        placeholder: 'NIDN',
                        ajax: {
                            url: '/dosens',
                            dataType: 'json',
                            delay: 250,
                            processResults: function (data) {
                                return {
                                results:  $.map(data, function (item) {
                                        return {
                                            text: item.nidn,
                                            id: item.nidn
                                        }
                                    })
                                };
                            },
                            cache: true
                        },
                        tags: true,
                        createTag: function(params){
                            return{
                                id : params.term,
                                text : params.term,
                                newOption : true
                            }
                        },
                    }
                );
            }
    </script>

    <script>
        var id = document.getElementById('id').value
        $.get('/staffs',{pkm:id}, function(data, textStatus, jqXHR){
            $.each(data,function(key,value){
                var newOption = new Option(value.nidn_nrp, value.nidn_nrp, true, true);
                $(`.nidn`)[key].append(newOption);
                console.log(newOption)
                $.get('/dosens',{q:value.nidn_nrp},function (dosen, textStatus,jqXHR){
                    document.getElementById(`nama[${key}]`).value = dosen.nama;
                    document.getElementById(`pend[${key}]`).value = dosen.pendidikan;
                    document.getElementById(`jab[${key}]`).value = dosen.jab_fungsional;
                    document.getElementById(`gol[${key}]`).value = dosen.golongan;
                    $(`select[name='prodi[${key}]'] option[value='${dosen.prodi}']`).prop('selected',true);
                    //Belum NIDN
                })
            })
        })
        function Update(key){
            var dt = $(`.nidn`)[key].value;
                console.log(dt)
                $.get('/dosens',{q:dt},function (dosen, textStatus,jqXHR){
                        console.log(dosen);  
                        document.getElementById(`nama[${key}]`).value = dosen.nama;
                        document.getElementById(`pend[${key}]`).value = dosen.pendidikan;
                        document.getElementById(`jab[${key}]`).value = dosen.jab_fungsional;
                        document.getElementById(`gol[${key}]`).value = dosen.golongan;
                        $(`select[name='prodi[${key}]'] option[value='${dosen.prodi}']`).prop('selected',true);
                        //Belum NIDN
                    })
        }
        
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('temp/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rizki\Desktop\kasir\resources\views/pkm/staff.blade.php ENDPATH**/ ?>